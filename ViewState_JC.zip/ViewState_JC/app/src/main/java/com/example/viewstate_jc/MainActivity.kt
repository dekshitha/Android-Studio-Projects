package com.example.viewstate_jc

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.Button
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.viewstate_jc.ui.theme.ViewState_JCTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ViewState_JCTheme {

                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    //MyButton2()

                    //using unidirection data flow and remember saveable to save state evn on rotation but not recom so use viewmodel
                    var count by rememberSaveable{mutableStateOf(0)}
                    MyButton3(count){
                        count=it+1
                    }
                }

            }
        }
    }
}



@Preview
@Composable
fun MyButton(){

    val context=LocalContext.current
    val count= remember{mutableStateOf(0)}

    Button(onClick = {
        count.value=count.value+1
        Toast.makeText(context, "Count is: ${count.value}", Toast.LENGTH_SHORT).show()
    },
        contentPadding = PaddingValues(16.dp),
        border = BorderStroke(10.dp, Color.Black),
        colors = ButtonDefaults.textButtonColors(
            backgroundColor = Color.DarkGray,
            contentColor = Color.White
        )

        ) {

        Text(text = "Count is: ${count.value}",
        style = MaterialTheme.typography.h5,
        modifier = Modifier.padding(5.dp))

    }


}

//using deligates -> changes in count
@Composable

fun MyButton2(){

    val context=LocalContext.current
    var count by remember{mutableStateOf(0)}

    Button(onClick = {
        count += 1
        Toast.makeText(context, "Count is: $count", Toast.LENGTH_SHORT).show()
    },
        contentPadding = PaddingValues(16.dp),
        border = BorderStroke(10.dp, Color.Black),
        colors = ButtonDefaults.textButtonColors(
            backgroundColor = Color.DarkGray,
            contentColor = Color.White
        )

    ) {

        Text(text = "Count is: $count",
            style = MaterialTheme.typography.h5,
            modifier = Modifier.padding(5.dp))

    }


}

//using stateless composable -> mostly used
//cant use preview fr funct with param

//sending state frm top-btm, event frm btm to top -> Unidirectional data flow using state hoisting
//two param->current value to display, an event that req current value to change
@Composable

fun MyButton3(currentCount:Int,updateCount:(Int)->Unit){

    val context=LocalContext.current

    Button(onClick = {
        updateCount(currentCount)
        //Toast.makeText(context, "Count is: $count", Toast.LENGTH_SHORT).show()
    },
        contentPadding = PaddingValues(16.dp),
        border = BorderStroke(10.dp, Color.Black),
        colors = ButtonDefaults.textButtonColors(
            backgroundColor = Color.DarkGray,
            contentColor = Color.White
        )

    ) {

        Text(text = "Count is: $currentCount",
            style = MaterialTheme.typography.h5,
            modifier = Modifier.padding(5.dp))

    }


}




package com.example.viewstate_jc

import androidx.lifecycle.ViewModel

class MyViewModel : ViewModel() {


}
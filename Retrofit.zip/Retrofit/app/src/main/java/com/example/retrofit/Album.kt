package com.example.retrofit

class Album : ArrayList<AlbumItem>()
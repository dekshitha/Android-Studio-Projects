package com.anushka.bindingdemo1

data class Student (
     var name: String,
     var id: Int
)
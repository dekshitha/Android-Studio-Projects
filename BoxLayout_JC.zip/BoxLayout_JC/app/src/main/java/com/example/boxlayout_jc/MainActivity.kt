package com.example.boxlayout_jc

import android.annotation.SuppressLint
import android.graphics.drawable.Icon
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.boxlayout_jc.ui.theme.BoxLayout_JCTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
             //BoxExample3()
            DisplaySnackBar()
        }
    }
}
//@Preview
@Composable
fun BoxExample1(){
    Box(
        modifier = Modifier
            .background(color = Color.Magenta)
            .size(180.dp, 300.dp)

    )   {
          Box(
              modifier = Modifier
                  .background(color = Color.LightGray)
                  .size(125.dp, 100.dp)
                  .align(Alignment.TopEnd)
          ){

          }
        Text(
            text="Hi",
            style = MaterialTheme.typography.h3,
            modifier = Modifier
                .background(color = Color.White)
                .size(90.dp, 50.dp)
                .align(Alignment.BottomCenter)
        )
    }
}
//@Preview
@Composable
fun BoxExample2(){
    Box(
        modifier = Modifier
            .background(color = Color.Blue)
            .fillMaxSize()
    )
    {
        Text(
            style=MaterialTheme.typography.h5,
            modifier = Modifier
                .background(Color.Yellow)
                .padding(10.dp)
                .align(Alignment.TopStart),
            text="TopStart"
        )
        Text(
            style=MaterialTheme.typography.h5,
            modifier = Modifier
                .background(Color.Yellow)
                .padding(10.dp)
                .align(Alignment.TopCenter),
            text="TopCenter"
        )
        Text(
            style=MaterialTheme.typography.h5,
            modifier = Modifier
                .background(Color.Yellow)
                .padding(10.dp)
                .align(Alignment.TopEnd),
            text="TopEnd"
        )
        Text(
            style=MaterialTheme.typography.h5,
            modifier = Modifier
                .background(Color.Yellow)
                .padding(10.dp)
                .align(Alignment.CenterStart),
            text="CenterStart"
        )
        Text(
            style=MaterialTheme.typography.h5,
            modifier = Modifier
                .background(Color.Yellow)
                .padding(10.dp)
                .align(Alignment.Center),
            text="Center"
        )
        Text(
            style=MaterialTheme.typography.h5,
            modifier = Modifier
                .background(Color.Yellow)
                .padding(10.dp)
                .align(Alignment.CenterEnd),
            text="CenterEnd"
        )
        Text(
            style=MaterialTheme.typography.h5,
            modifier = Modifier
                .background(Color.Yellow)
                .padding(10.dp)
                .align(Alignment.BottomStart),
            text="Bottom Start"
        )
        Text(
            style=MaterialTheme.typography.h5,
            modifier = Modifier
                .background(Color.Yellow)
                .padding(10.dp)
                .align(Alignment.BottomCenter),
            text="Bottom Center"
        )
        Text(
            style=MaterialTheme.typography.h5,
            modifier = Modifier
                .background(Color.Yellow)
                .padding(10.dp)
                .align(Alignment.BottomEnd),
            text="Bottom End"
        )
    }
}
//@Preview
@Composable
fun BoxExample3(){
    val context= LocalContext.current
    Box(){
        Image(
            painter = painterResource(id=R.drawable.img),
            contentDescription ="beach resort"
        )
        Text(
            text = "Amsterdam",
            style = MaterialTheme.typography.h6,
            color = Color.White,
            modifier=Modifier
                    .align(Alignment.BottomCenter)
            )
        //other types->text button, outlinedbutton, iconbutton
        Button(onClick = {
           Toast.makeText(context,"Clicked on Button",Toast.LENGTH_LONG).show()
        },
               colors = ButtonDefaults.textButtonColors(
                   backgroundColor = Color.White,
                   contentColor = Color.DarkGray
               ),
            shape= CircleShape,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp)
                .border(5.dp, Color.DarkGray, CircleShape)
            ) {
              Text("Add")
        }
        Icon(
            Icons.Filled.Refresh,
            contentDescription = "refresh btn",
            tint=Color.White,
            modifier = Modifier.size(40.dp)
        )
    }
}

//@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Preview
@Composable
//snackbar->alternative to toast msg
fun DisplaySnackBar() {
    val scaffoldState :ScaffoldState = rememberScaffoldState()
    val coroutineScope :CoroutineScope = rememberCoroutineScope()

    //scaffold state->layout

    Scaffold(scaffoldState = scaffoldState) {
      Button(onClick = {
          coroutineScope.launch {
             val snackBarResult = scaffoldState.snackbarHostState.showSnackbar(
                 message="This is the message",
                 actionLabel = "Undo",
                 duration = SnackbarDuration.Long
             )
              when(snackBarResult){
                  SnackbarResult.ActionPerformed -> Log.i("mytag","action label clicked")
                  SnackbarResult.Dismissed -> Log.i("mytag","dismissed")
              }
          }
      }) {
          Text(text = "Displaying snack bar")
      }  
    }


}




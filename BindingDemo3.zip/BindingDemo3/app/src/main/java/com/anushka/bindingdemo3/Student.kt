package com.anushka.bindingdemo3

data class Student (
    var id:Int,
    var name:String,
    var email:String
)
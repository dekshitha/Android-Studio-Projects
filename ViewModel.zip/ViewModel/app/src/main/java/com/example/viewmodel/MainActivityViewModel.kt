package com.example.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainActivityViewModel(startingTotal : Int) : ViewModel() {

    private var count = MutableLiveData<Int>()
    val total : LiveData<Int>
    get()=count

    val inputText=MutableLiveData<String>()

    init{
        count.value=startingTotal
    }


    fun getUpdatedCount(){
        val intInput:Int=inputText.value!!.toInt()
        count.value= (count.value)?.plus(intInput)
    }


}